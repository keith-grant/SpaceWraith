#pragma once
#ifndef GAME_H
#define GAME_H

#include<iostream>

#include<SFML\Window.hpp>
#include<SFML\Graphics.hpp>

#include"Room.h"
#include "Actor.h"

#include"Explosion.h"
#include <random>

class Game
{
private:
	Room *r;
	Actor act;
	int level;
	int trueLevel;
	sf::View view;
	bool shaking;
	float x_offset;
	float y_offset;

	int score;

	sf::Font courier;
	sf::Text scoreText;
	sf::String scoreString;

	bool scoreCalculated;
	bool fadedIn;

	sf::Sprite blackBack;
	sf::Texture black_tex;

	sf::Sprite shipSides;
	sf::Texture shipSidesTex;

	sf::Texture fadeTex;
	sf::Sprite fadeSprite;


	sf::Texture introBackTex;
	sf::Sprite introBackSprite;

	sf::Texture introFrontTex;
	sf::Sprite introFrontSprite;

	sf::Texture introTitleText;
	sf::Sprite introTitleSprite;

	sf::Texture explanationText;
	sf::Sprite explanationSprite;

	sf::Texture heartTexture;
	sf::Sprite heartSprite;

	sf::Texture PDALightTexture;
	sf::Sprite PDALightSprite;
	int PDALightCounter;

	float beatDirection;

	sf::Texture redTex;
	sf::Sprite redSprite;

	sf::Clock heartClock;
	float heartBeat;
	float currentTime;

	int counter;
	bool isIntro;
	bool explanationOpen;
	bool introButtonPressed;

	bool fadeOutComplete;
	bool fadeInComplete;
	bool fading;
	bool deathRoom;

	int loop;

	Explosion* explosion;
	bool tutorial;
	sf::Sound screamSound;
	sf::SoundBuffer screamBuffer;

	bool tutorialOn;

	sf::Music introTune;


	sf::Texture starPointTex;
	sf::Sprite starSpritesLayer1[128];
	sf::Sprite starSpritesLayer2[128];
	sf::Sprite starSpritesLayer3[128];

	std::default_random_engine generator;

public:
	Game(void);
	~Game(void);

	void init();
	void render(sf::RenderWindow* w);
	void update();
	void handleEvent(sf::Event e);

	void fadeOut();
	void fadeIn();


	void finalFade();

	void loadStars();


};

#endif