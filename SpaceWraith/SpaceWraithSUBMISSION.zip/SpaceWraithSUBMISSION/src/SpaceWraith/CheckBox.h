#pragma once
#ifndef CHECK_BOX_H
#define CHECK_BOX_H

#include "uiwidget.h"
class CheckBox : public UIWidget
{
public:
	CheckBox(std::string inFilename, float inXPosition, float inYPosition);
	~CheckBox(void);

	void update(std::vector<CodeElement> code);
	void render(sf::RenderWindow* w);
	void addButton(CodeElement inElement);
	bool getMatch(){return match;}
	void setMatch(){match = true;}

	


private:

	sf::Sound wrongCodeSound;
	sf::SoundBuffer wrongCodeBuffer;

	bool match;
	std::vector<UIWidget*> buttons;
	std::vector<CodeElement> button_elements;
};

#endif