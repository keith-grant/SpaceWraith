#pragma once
#ifndef CODEBOX_H
#define CODEBOX_H

#include "UIWidget.h"
#include <vector>



class CodeBox : public UIWidget
{
public:
	CodeBox(std::string inFilename, float inPositionX, float inPositionY, std::vector<CodeElement> inElements);
	~CodeBox(){}
	void render(sf::RenderWindow* w);
	void setRenderStatus(bool inbool){ toRender = inbool ;}
	void flicker(float secs);
	bool isHidden();

private:
	std::vector<UIWidget*> codeVector;
	bool toRender;

	int flickered;			// How many times the torch has flickered
	int requiredFlicker;	// How many times you want the torch to flicker

	bool hidden;		// whether or not the torch is flickering

	sf::Texture flickerTex;		// the texture overlay that causes the flicker
	sf::Sprite flickerSprite;
};

#endif