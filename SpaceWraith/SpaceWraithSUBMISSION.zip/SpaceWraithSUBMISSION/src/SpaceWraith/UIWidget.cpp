#include "UIWidget.h"


UIWidget::UIWidget(std::string inFilename, float inXPosition, float inYPosition)
{
	active = false;
	tex.loadFromFile(inFilename);

	sprite.setTexture(tex);

	sprite.setColor(sf::Color(255, 255, 255, 255));
	sprite.setPosition(inXPosition, inYPosition);
}

void UIWidget::render(sf::RenderWindow * w)
{
	if(active)
	{
		w->draw(sprite);
	}
}