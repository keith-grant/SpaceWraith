#include "Tile.h"



Tile::Tile(char t, sf::Vector2f pos)
{	
	type = t;
	toRender = true;
	pickup = false;
	played = false;
	// Decide which type of tile this is based on the character passed in. Extend the switch statement if required.
	switch(t)
	{
	case 'a':
		//  something else
		tex.loadFromFile("art/tile_paper_pile.png");
		blank = true;
		break;
	case 'b':
		//  something else
		tex.loadFromFile("art/tile_blood_stain.png");
		blank = true;
		break;
	case 'c':
		//  something else
		tex.loadFromFile("art/tile_blood_stain2a.png");
		blank = true;
		break;
	case 'd':
		//  something else
		tex.loadFromFile("art/tile_blood_stain2b.png");
		blank = true;
		break;
	case 'e':
		//  something else
		tex.loadFromFile("art/tile_blood_stain2c.png");
		blank = true;
		break;
	case 'f':
		//  something else
		tex.loadFromFile("art/tile_blood_stain2d.png");
		blank = true;
		break;
	case 'g':
		tex.loadFromFile("art/tile_chair.png");
		blank = false;
		break;
	case 'h':
		tex.loadFromFile("art/tile_table.png");
		blank = false;
		break;
	case 'i':
		// joining table
		tex.loadFromFile("art/tile_joining_table.png");
		blank = false;
		break;
	case 'j':
		// joining table
		tex.loadFromFile("art/tile_lab_table.png");
		blank = false;
		break;
	case 'k':
		// Oscilliscope
		tex.loadFromFile("art/tile_oscil.png");
		blank = false;
		break;
	case 'o':
		// blank
		blank = true;
		break;
	case 'p':
		tex.loadFromFile("art/tile_pda.png");
		blank = true;
		pickup = true;

		pickBuffer.loadFromFile("Sound/pickup.wav");
		
		pickSound.setVolume(100);
		
		break;
	case 'l':
		tex.loadFromFile("art/tile_bloody_gibletsa.png");
		blank = true;
		pickup = false;
		break;
	case 'm':
		tex.loadFromFile("art/tile_bloody_gibletsb.png");
		blank = true;
		pickup = false;
		break;
	case 'n':
		tex.loadFromFile("art/tile_circuits.png");
		blank = false;
		pickup = false;
		break;
	case 'q':
		tex.loadFromFile("art/tile_pc.png");
		blank = false;
		pickup = false;
		break;
	case 'r':
		tex.loadFromFile("art/tile_water1.png");
		blank = true;
		pickup = false;
		break;
	case 's':
		tex.loadFromFile("art/tile_water2.png");
		blank = true;
		pickup = false;
		break;
	case 't':
		tex.loadFromFile("art/tile_test_tube_pile.png");
		blank = false;
		pickup = false;
	default:
		// BLANK SQUARE
		blank = true;
		break;
	}
	// Create a sprite
	sprite.setTexture(tex);
	sprite.setColor(sf::Color(255, 255, 255, 255));
	sprite.setPosition(pos);
}


Tile::~Tile()
{

}

// Return the sprite associated with this tile
sf::Sprite Tile::getSprite()
{
	return sprite;		
}

// Return whether or not this tile is blank (i.e. can be walked on)
bool Tile::isBlank()
{
	return blank;
}

void Tile::render(sf::RenderWindow* w)
{
	sprite.setTexture(tex);
	if(toRender)
	{
		w->draw(sprite);
	}else{
		if(!played){
			pickSound.setBuffer(pickBuffer);
			pickSound.play();
			played = true;
		}
	}
}

bool Tile::isPDA()
{
	return pickup;
}

void Tile::dontRender()
{
	toRender = false;
}