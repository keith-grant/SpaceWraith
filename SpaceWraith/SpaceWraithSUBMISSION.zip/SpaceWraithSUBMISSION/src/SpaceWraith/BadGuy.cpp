#include "BadGuy.h"



BadGuy::BadGuy(void)
{
	tex.loadFromFile("art/wraith.png");

	// Create a sprite
	sprite.setTexture(tex);
	sprite.setColor(sf::Color(255, 255, 255, 255));
	
	sprite.setOrigin(64,64);

	buffer.loadFromFile("Sound/beat2.wav");
	beat.setBuffer(buffer);
	beat.setLoop(true);
	beat.setVolume(20);
	beat.setPitch(0.5);
	beat.play();

	volume = 0.0;
	pitch = 0.0;
	deathCutoff = 3.0f;


	killPlayer = false;
}

void BadGuy::pauseSound()
{
	if(beat.getStatus() == sf::SoundSource::Status::Playing){
		beat.pause();
	}
}

void BadGuy::playSound()
{
	if(beat.getStatus() == sf::SoundSource::Status::Paused){
		beat.play();
	}
}

BadGuy::~BadGuy(void)
{
}

void BadGuy::update()
{
	if(!killPlayer){
		beat.setVolume(volume);
		beat.setPitch(pitch);
		float i = beat.getPitch();
		
		if(i > deathCutoff)
		{
			killPlayer = true;
		}
	}else{
		beat.setVolume(80);
		beat.setPitch(0.75);
	}
}

void BadGuy::setIncreaseRates(int levelNo)
{
	volume = (levelNo * 0.01) + beat.getVolume();
	pitch = (levelNo * 0.0005) + beat.getPitch();
	level_number = levelNo;
}


void BadGuy::render(sf::RenderWindow *w)
{

	if(beat.getPitch() > deathCutoff - ((level_number * 0.0005)*3)){
		w->draw(sprite);
	}
}

void BadGuy::setPosition(sf::Vector2f pos)
{
	sprite.setPosition(pos);
}