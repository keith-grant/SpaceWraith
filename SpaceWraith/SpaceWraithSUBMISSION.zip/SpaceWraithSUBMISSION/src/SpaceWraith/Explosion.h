#pragma once
#ifndef EXPLOSION_H
#define EXPLOSION_H

#include<SFML\Window.hpp>
#include<SFML\Graphics.hpp>
#include<SFML/Audio.hpp>

#include <random>
#include <time.h>


class Explosion
{
public:
	Explosion(void);
	~Explosion(void);

	void update();
	void render(sf::RenderWindow* w);

	sf::Sound explSound;
	sf::SoundBuffer explSndBuffer;


	bool exploding;

private:
	sf::Texture explosion_tex;
	sf::Sprite explosion;
	int frame_count;
	int current_cell;
};
#endif