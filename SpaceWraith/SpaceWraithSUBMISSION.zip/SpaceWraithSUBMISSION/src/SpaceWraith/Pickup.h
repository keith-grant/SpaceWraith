#ifndef PICKUP_H
#define PICKUP_H

#include<SFML\Window.hpp>
#include<SFML\Graphics.hpp>
#include<SFML\Window.hpp>

class Pickup
{
public:
	Pickup();
	~Pickup();

	void pickUp();
	bool isPickedUp();


private:
	bool pickedUp;
	sf::Texture tex;
	sf::Sprite sprite;
};

#endif // PICKUP.H