#include "peedeeay.h"

peedeeay::peedeeay(int* code)
{

}

peedeeay::~peedeeay()
{

}

int *peedeeay::getCode()
{
	return code;
}