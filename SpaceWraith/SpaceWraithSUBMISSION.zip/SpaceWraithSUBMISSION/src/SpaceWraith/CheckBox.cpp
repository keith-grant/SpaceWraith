#include "CheckBox.h"


CheckBox::CheckBox(std::string inFilename, float inXPosition, float inYPosition) : UIWidget(inFilename, inXPosition, inYPosition)
{
	match = false;

	wrongCodeBuffer.loadFromFile("Sound/incorrect_code.wav");
	wrongCodeSound.setBuffer(wrongCodeBuffer);
	wrongCodeSound.setVolume(50);
}


CheckBox::~CheckBox(void)
{
}

void CheckBox::update(std::vector<CodeElement> code)
{
	bool equal = true;
	if(buttons.size() == 4)
	{
		for(int i = 0; i < 4; i++)
		{
			if(code[i] != button_elements[i])
			{
				buttons.clear();
				button_elements.clear();
				equal = false;
				wrongCodeSound.play();
				break;
			}
		}
		if(equal)
		{
			match = true;
		}
	}

}

void CheckBox::render(sf::RenderWindow* w)
{
	if(active)
	{
		UIWidget::render(w);
		for(int i = 0; i < buttons.size(); i++)
		{
			buttons[i]->render(w);
		}
	}
}

void CheckBox::addButton(CodeElement inElement)
{
	switch (inElement)
	{
	case X_BUTTON: 
		{
			UIWidget* temp = new UIWidget("art/x_button.png", sprite.getPosition().x + (48.0f * (buttons.size() + 1)), sprite.getPosition().y + 128.0f);
			temp->setActive();
			buttons.push_back(temp);
			button_elements.push_back(inElement);
		}
		break;
	case Y_BUTTON:
		{
			UIWidget* temp = new UIWidget("art/y_button.png", sprite.getPosition().x + (48.0f * (buttons.size() + 1)), sprite.getPosition().y + 128.0f);
			temp->setActive();
			buttons.push_back(temp);
			button_elements.push_back(inElement);
		}
		break;
	case A_BUTTON:
		{
			UIWidget* temp = new UIWidget("art/a_button.png", sprite.getPosition().x + (48.0f * (buttons.size() + 1)), sprite.getPosition().y + 128.0f);
			temp->setActive();
			buttons.push_back(temp);
			button_elements.push_back(inElement);
		}
		break;
	case B_BUTTON:
		{
			UIWidget* temp = new UIWidget("art/b_button.png", sprite.getPosition().x + (48.0f * (buttons.size() + 1)), sprite.getPosition().y + 128.0f);
			temp->setActive();
			buttons.push_back(temp);
			button_elements.push_back(inElement);
		}
	}
}