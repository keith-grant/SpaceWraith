#pragma once
#ifndef DOOR_H
#define DOOR_H

#include <SFML\Graphics.hpp>
#include <SFML\Window.hpp>

enum DoorState 
	{
		OPEN, OPENING, CLOSED, CLOSING
	};


class Door
{
public:
	Door(void);
	~Door(void);

	void update();
	void render(sf::RenderWindow * w);

	void openDoor() { open = true; }
	DoorState doorState;

	void leftMove();
	void rightMove();

private:
	sf::Texture l_tex;
	sf::Texture r_tex;
	sf::Sprite leftDoor;
	sf::Sprite rightDoor;

	bool open;


};


#endif // !DOOR_H
