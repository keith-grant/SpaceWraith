

#include "Game.h"


Game *g;

int main()
{

	g = new Game();

	

	sf::RenderWindow* window = new sf::RenderWindow(sf::VideoMode(1024, 768), "Space Wraith", sf::Style::None);
	//sf::RenderWindow* window = new sf::RenderWindow(sf::VideoMode(1024, 768), "Donor", sf::Style::Fullscreen);
	
	window->setFramerateLimit(120);
	window->setMouseCursorVisible(false);

	// Start game loop
    while (window->isOpen())
    {
		sf::Event event;
        
		if(window->pollEvent(event))
		{
			g->handleEvent(event);
		}

		g->update();
		g->render(window);

	    // Escape key pressed
		if ((event.type == sf::Event::KeyPressed) && (event.key.code == sf::Keyboard::Escape))
			window->close();


		window->display();

    }
	
	delete window;
	delete g;

	return 0;
}