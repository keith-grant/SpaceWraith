#include "Room.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <random>
#include <time.h>

Room::Room(std::string fname)
{
	complete = false;
	texture.loadFromFile("art/room_default.png");

	// Create a sprite
	background.setTexture(texture);

	////sprite.setTextureRect(sf::IntRect(10, 10, 50, 30));
	background.setColor(sf::Color(255, 255, 255, 255));
	background.setPosition(128, 0);
	std::ifstream::pos_type size;
	char * memblock;

	std::ifstream file (fname, std::ios::in|std::ios::binary|std::ios::ate);
	if (file.is_open())
	{
		size = file.tellg();
		memblock = new char [(int)size];
		file.seekg (0, std::ios::beg);
		file.read (memblock, size);
		file.close();
	}
	else
	{	
		return;
	}
	
	std::stringstream strstream(memblock); 	
	float x = 192;
	float y = 64;
	for(int i = 0; i < 100; i++)
	{
		char c;
		strstream >> c;
		tiles.push_back(Tile(c, sf::Vector2f(x, y)));
		x += 64;
		if(x >768)
		{
			x = 192;
			y += 64;
		}

		if(c == 'p')
		{
			PDALightPos = new sf::Vector2f(x-32, y+16);
		}
	}

	generateCode();
	codeBox = new CodeBox("art/pda.png", 10.0f, 0.0f, elements);
	pop_up = new CheckBox("art/code_popup.png", 384.0f, 384);
	t_door = new Door();
	b_door = new Door();

	tutorialSection = 0;

	pdaExplanation = new UIWidget("art/tutorial_bubble1.png", 200, 450);
	codeExplanation = new UIWidget("art/tutorial_bubble2.png", 120, 257);

	pdaExplanation->setActive();

	initialiseSounds();
}

BadGuy * Room::getBadGuy()
{
	return &wraith;
}

Room::~Room(void)
{
}

void Room::initialiseSounds()
{
	for(int i = 0; i < 6; i++)
	{
		sf::Sound newSound;

		switch(i)
		{
		case 0:
			breathingBuffer.loadFromFile("Sound/breathing.wav");
			newSound.setBuffer(breathingBuffer);
			break;
		case 1:
			pipeBuffer.loadFromFile("Sound/pipe.wav");
			newSound.setBuffer(pipeBuffer);
			break;
		case 2:
			emergencyBuffer.loadFromFile("Sound/emergencyprotocol.wav");
			newSound.setBuffer(emergencyBuffer);
			break;
		case 3:
			decliningBuffer.loadFromFile("Sound/lifesupportdeclining.wav");
			newSound.setBuffer(decliningBuffer);
			break;
		case 4:
			terminatedBuffer.loadFromFile("Sound/inadvertentlyterminated.wav");
			newSound.setBuffer(terminatedBuffer);
			break;
		case 5:
			seriousBuffer.loadFromFile("Sound/seriousfault.wav");
			newSound.setBuffer(seriousBuffer);
			break;
		default:
			pipeBuffer.loadFromFile("Sound/pipe.wav");
			newSound.setBuffer(pipeBuffer);
			break;
		}

		newSound.setLoop(false);
		newSound.setVolume(50);

		soundList.push_back(newSound);
	}

	soundPlaying = false;
}

void Room::render(sf::RenderWindow* w)
{
	w->draw(background);
	for(unsigned int i = 0; i < tiles.size(); i++)
	{
		tiles[i].render(w);
	}

	if(tutorial)
	{
		pdaExplanation->render(w);
		codeExplanation->render(w);
	}
	
//	wraith.render(w);
}


void Room::setComplete()
{
	complete = true;
	pop_up->setMatch();
}

void Room::update(bool intro)
{
	pop_up->update(elements);
	t_door->update();
	b_door->update();
	
	if(!intro){
		wraith.update();
	}
	if(!wraith.killPlayer){
		if(!soundPlaying)
		{
			int number = 0 + (std::rand() % (int)(2000 - 0 + 1));

			if(number > 1995)
			{
				int soundNo = 0 + (std::rand() % (int)((soundList.size()-1) - 0 + 1));

				soundList.at(soundNo).play();

				soundPlaying = true;
			}
		}
		else
		{	
			for(int i = 0; i < soundList.size(); i++)
			{
				if(soundList.at(i).getStatus() == sf::SoundSource::Status::Playing)
				{
					soundPlaying = true;
					break;
				}
				else
				{
					soundPlaying = false;
				}
			}
		}
	}
}


bool Room::getKillPlayer()
{
	return wraith.killPlayer;
}


void Room::renderCodeBox(sf::RenderWindow* w)
{
		codeBox->render(w);
		pop_up->render(w);
		t_door->render(w);
		b_door->render(w);
}

bool Room::getComplete()
{
	complete = pop_up->getMatch();
	t_door->openDoor();
	return complete;
}

void Room::generateCode()
{
	srand(time(NULL));
	int number = 0;
	for(int i = 0; i < 4; ++i)
	{
		number = rand()%4;
		elements.push_back((CodeElement)number);
	}	
}

CodeBox* Room::getCodeBox()
{
	return codeBox;
}

CheckBox* Room::getPopUp()
{
	return pop_up;
}

void Room::setTutorial(bool tut)
{
	tutorial = tut;
}

void Room::firstTutorialSection()
{
	if(tutorial)
	{
		if(pdaExplanation->getActive() && tutorialSection == 0)
		{
			pdaExplanation->setInActive();
			codeExplanation->setActive();
		}
	}
}

void Room::secondTutorialSection()
{
	if(tutorial)
	{
		if(codeExplanation->getActive() && tutorialSection == 1)
		{
			codeExplanation->setInActive();
		}
	}
}

void Room::setPDALightPos(sf::Vector2f* inPos)
{
	PDALightPos = inPos;
}