#include "Actor.h"

#include<iostream>

Actor::Actor(void):moveScale(0.0075f),deadZone(20.0f)
{
	 xb = false;
	 yb = false;
	 ab = false;
	 bb = false;

	 firstLevel = true;

	 flickering = false;
	 flickered = 0;

	 timeOut = 1.5;
	 currentTime = 0.0;
	 timing = false;

	texLightOff.loadFromFile("art/player_with_mask2.png");
	texLightOn.loadFromFile("art/player_without_mask.png");

	torchFlickerTex.loadFromFile("art/torch_flicker.png");

	texOrangeLight.loadFromFile("art/orange_light_mask2.png");
	torchFlickerSprite.setTexture(torchFlickerTex);
	torchFlickerSprite.setColor(sf::Color(255, 255, 255, 0));
	torchFlickerSprite.setPosition(512, 670);
	torchFlickerSprite.setOrigin(1129,1050);

	//tex.loadFromFile("art/tester2.png");
	// Create a sprite
	sprite.setTexture(texLightOff);


	////sprite.setTextureRect(sf::IntRect(10, 10, 50, 30));
	sprite.setColor(sf::Color(255, 255, 255, 255));
	sprite.setPosition(512, 670);
	sprite.setOrigin(1129,1050);
	
	
}


void Actor::render(sf::RenderWindow * w)
{
	// Use the main window to render sprite.

	w->draw(sprite);
	w->draw(torchFlickerSprite);
}

void Actor::flicker(bool firstLevel)
{
	if(!firstLevel)		// check whether or not we are in the first level (since the first level has all the lights on)
	{
		int flicker;

		if(!flickering)		// If the torch is not already flickering
		{
				int number = 0 + (std::rand() % (int)(2000 - 0 + 1));		// Random number to decide whether or not to bother flickering

				if(number > 1990)		// Increase/decrease this number to make flickering less/more common
				{
					requiredFlicker = 0 + (std::rand() % (int)(50 - 0 + 1));		// Randomises the number of times the torch flickers
					flickering = true;			// Torch is now flickering
				}
		}
		else		// If the torch is flickering
		{
			flickered++;		// Increase the number of times it has flickered 

			flicker = 0 + (std::rand() % (int)(510 - 0 + 1));		// Randomise the colour value for the alpha between 0 and 255

			if(flicker > 255)
			{
				if(flickered % 4 == 0)		// Spaces out the flickers
				{
					sprite.setTexture(texOrangeLight);
				}
				else
				{
					sprite.setTexture(texLightOff); // Turn the torch back on
				}

			}
			else
			{
				if(flickered % 4 == 0)		// Spaces out the flickers
				{
					torchFlickerSprite.setColor(sf::Color(255, 255, 255, flicker));		// Turn the torch down/off
				}
				else
				{
					torchFlickerSprite.setColor(sf::Color(255, 255, 255, 0));		// Turn the torch back on
				}
			}

			if(flickered >= requiredFlicker)		// If the torch has flickered enough
			{
				flickering = false;
				requiredFlicker = 0;
				flickered = 0;
				sprite.setTexture(texLightOff); // Turn the torch back on
				torchFlickerSprite.setColor(sf::Color(255, 255, 255, 0));		// Reset all the torch stuff
			}
		}
	}
}

void Actor::update(Room * r)
{
	currentTime = clock.getElapsedTime().asSeconds();

	//	Get controller axes' values
	float xAxis = sf::Joystick::getAxisPosition(0,sf::Joystick::X);
	float yAxis = sf::Joystick::getAxisPosition(0,sf::Joystick::Y);


	//	Get angle from controller coordinates

	float angle = atan2(xAxis,-yAxis);

	float d2r = 180.0f/3.14159;


	// Movement distance vars
	float xDist = 0.0f,yDist = 0.0f;

	flicker(firstLevel);
	
	bool move = true;
	if(sqrt((xAxis * xAxis) + (yAxis * yAxis)) > deadZone)
	{
		sprite.setRotation((angle * d2r));
		torchFlickerSprite.setRotation((angle * d2r));
		move = false;
	}

	xDist = xAxis * moveScale;
	yDist = yAxis * moveScale;
	//	Move sprite
	int x_off = 16;
	if(sprite.getPosition().x + x_off + xDist < 832 && sprite.getPosition().x - x_off + xDist > 192)
	{
		if(sprite.getPosition().y + x_off + yDist < 704 && sprite.getPosition().y - x_off + yDist > 64)
		{
			int act_x = 0;
			int act_y = 0;
			if(xAxis > 0)
			{
				act_x = (sprite.getPosition().x + x_off + xDist - 192) / 64;
				if(yAxis > 0)
				{
					act_y = (sprite.getPosition().y + x_off + yDist - 64) / 64;
				}
				else
				{
					act_y = (sprite.getPosition().y - x_off + yDist- 64) / 64;
				}

			}
			if(xAxis <= 0)
			{
				act_x = (sprite.getPosition().x - x_off + xDist - 192) / 64;
				if(yAxis > 0)
				{
					act_y = (sprite.getPosition().y + x_off + yDist - 64) / 64;
				}
				else
				{
					float jokjo = sprite.getPosition().y;
					act_y = (sprite.getPosition().y - x_off + yDist - 64) / 64;
				}	
			}

			int check = act_x + (10 * act_y);
			if(r->tiles[check].isBlank())
			{
				if(!move)
				{
					if(r->tiles[check].isPDA())
					{
						r->tiles[check].dontRender();
						r->getCodeBox()->setActive();
						r->setPDALightPos(new sf::Vector2f(-100.0f, -100.0f));
						r->firstTutorialSection();

						if(!r->getCodeBox()->isHidden())
						{
							clock.restart();
							currentTime = clock.getElapsedTime().asSeconds();
							r->getCodeBox()->flicker(0.0f);
						}
						
					}
					sprite.move(xDist,yDist);
					torchFlickerSprite.move(xDist, yDist);
				}

			}
		}
	}
	if(r->getCodeBox()->getActive())
	{
		if(sprite.getPosition().y < 128)
		{
			if(sprite.getPosition().x > 448 && sprite.getPosition().x < 576)
			{
				r->getPopUp()->setActive();
				r->getCodeBox()->setRenderStatus(false);
				readCode(r);
			}
			else
			{
				r->getPopUp()->setInActive();

				r->secondTutorialSection();
			}
		}
		else
		{
			r->getPopUp()->setInActive();
			r->getCodeBox()->flicker(currentTime);
		}
	}

	r->getBadGuy()->setPosition(sprite.getPosition());
}

void Actor::readCode(Room* r)
{
	if(r->getPopUp()->getActive())
	{
		if(bool p = sf::Joystick::isButtonPressed(0,0))
		{
			if(!ab)
			{
				r->getPopUp()->addButton(A_BUTTON);
			}
			ab = true;
			
		}
		else
		{
			ab = false;
		}
		if(bool p = sf::Joystick::isButtonPressed(0,1))
		{
			if(!bb)
			{
				r->getPopUp()->addButton(B_BUTTON);
			}
			bb = true;
			
		}
		else
		{
			bb = false;
		}
		if(bool p = sf::Joystick::isButtonPressed(0,2))
		{
			if(!xb)
			{
				r->getPopUp()->addButton(X_BUTTON);
			}
			xb = true;
			
		}
		else
		{
			xb = false;
		}
		if(bool p = sf::Joystick::isButtonPressed(0,3))
		{
			if(!yb)
			{
				r->getPopUp()->addButton(Y_BUTTON);
			}
			yb = true;
			
		}
		else
		{
			yb = false;
		}
		
	}
}

void Actor::switchLightsOff()
{
	sprite.setTexture(texLightOff);
	firstLevel = false;
}

void Actor::switchLightsOn()
{
	sprite.setTexture(texLightOn);
	firstLevel = true;
}

Actor::~Actor(void)
{
}

void Actor::resetPosition()
{
	sprite.setPosition(512, 670);
	sprite.setRotation(0.0f);
	torchFlickerSprite.setPosition(512, 670);
	torchFlickerSprite.setRotation(0.0f);
}


sf::Vector2f Actor::getPlayerPos()
{
	return sprite.getPosition();
}