#pragma once
#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <SFML\Graphics.hpp>
#include <SFML\Window.hpp>
#include <SFML\Audio.hpp>
#include <string>

enum CodeElement
{
	A_BUTTON,
	B_BUTTON,
	X_BUTTON,
	Y_BUTTON
};

class UIWidget
{
public:

	UIWidget(std::string inFilename, float inXPosition, float inYPosition);
	~UIWidget(){};

	void render(sf::RenderWindow * w);


	void setActive() { active = true; }
	void setInActive() {active = false;}
	bool getActive() { return active; }

protected:

	bool active;
	sf::Sprite sprite;
	sf::Texture tex;

};

#endif