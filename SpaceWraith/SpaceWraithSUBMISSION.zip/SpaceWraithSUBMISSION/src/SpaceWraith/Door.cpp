#include "Door.h"


Door::Door(void)
{
	sf::Texture l_tex;
	sf::Texture r_tex;
	sf::Sprite leftDoor;
	sf::Sprite rightDoor;

	l_tex.loadFromFile("art/door_left.png");
	leftDoor.setTexture(l_tex);
	leftDoor.setColor(sf::Color(255, 255, 255, 255));
	leftDoor.setPosition(400, 0);
	r_tex.loadFromFile("art/door_right.png");
	rightDoor.setTexture(r_tex);
	rightDoor.setColor(sf::Color(255, 255, 255, 255));
	rightDoor.setPosition(624, 0);
	open = false;
}


Door::~Door(void)
{
}

void Door::update()
{
	if(open)
	{
		leftMove();
		rightMove();
	}
}

void Door::render(sf::RenderWindow * w)
{
	w->draw(leftDoor);
	w->draw(rightDoor);
}

void Door::leftMove()
{
	if(leftDoor.getPosition().x > 350)
	{
		leftDoor.move(-10.0f, 0.0f);
	}
	else
		 
	{
		open = false;
	}
}
void Door::rightMove()
{
	if(rightDoor.getPosition().x < 674)
	{
		rightDoor.move(10.0f, 0.0f);
	}
	else
	{
		open = false;
	}
}


