#ifndef TILE_H
#define TILE_H

#include<SFML\Window.hpp>
#include<SFML\Graphics.hpp>
#include<SFML\Audio.hpp>

class Tile
{
public:
	Tile(char t, sf::Vector2f pos);						// Passes the character from the level file telling the tile what type it is
	~Tile();							// Default destructor
	sf::Sprite getSprite();				// Return the sprite associated with this tile
	bool isBlank();						// Returns true if the tile has nothing on it and false otherwise
	void render(sf::RenderWindow* w);	//draws the tile
	bool isPDA();
	void dontRender();
	

private:
	sf::Texture tex;
	sf::Sprite sprite;					// The sprite for this tile
	char type;							// The character associated with this tile type
	bool blank;							// Whether or not the tile has something on it


	bool played;
	bool toRender;
	bool pickup;
	sf::Sound pickSound;
	sf::SoundBuffer pickBuffer;
};

#endif //TILE.H