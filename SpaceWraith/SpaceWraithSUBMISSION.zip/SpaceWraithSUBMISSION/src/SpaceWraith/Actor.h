#pragma once
#ifndef ACTOR_H
#define ACTOR_H

#include <SFML\Graphics.hpp>
#include <SFML\Window.hpp>
#include <SFML\Audio.hpp>

#include "Room.h"


class Actor
{
private:
	// Main sprite for our hero/villain/player
	sf::Sprite sprite;
	sf::Texture texLightOff;
	sf::Texture texLightOn;
	sf::Texture texOrangeLight;
	sf::Sound h_beat;
	sf::SoundBuffer buffer;
 
	float distance;

	// A float for scaling the controller vs. movement speed
	float moveScale;
	float deadZone;

	bool xb;
	bool yb;
	bool ab;
	bool bb;

	float timeOut;
	float currentTime;
	bool timing;

	sf::Clock clock;

	bool firstLevel;

	int flickered;			// How many times the torch has flickered
	int requiredFlicker;	// How many times you want the torch to flicker

	bool flickering;		// whether or not the torch is flickering

	sf::Texture torchFlickerTex;		// the texture overlay that causes the flicker
	sf::Sprite torchFlickerSprite;		// The sprite which is displayed to cause the flicker

	

public:
	// Ctor
	Actor();

	// Dtor
	~Actor();

	// Method updates the position of actor prior to drawing.
	void update(Room *r);
	void render(sf::RenderWindow * w);

	void readCode(Room *r);

	void flicker(bool firstLevel);		// Function to make the torch flicker, called every update and told whether its the first level or not
	void resetPosition();
	void switchLightsOn();
	void switchLightsOff();

	sf::Vector2f getPlayerPos();
};

#endif