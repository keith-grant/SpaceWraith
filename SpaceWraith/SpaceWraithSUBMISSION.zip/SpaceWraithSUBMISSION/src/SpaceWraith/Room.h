#pragma once
#ifndef ROOM_H
#define ROOM_H

#include<vector>
#include<SFML\Graphics.hpp>
#include<SFML\Window.hpp>

#include"Tile.h"
#include"Door.h"
#include "CodeBox.h"
#include "CheckBox.h"
#include "BadGuy.h"



class Room
{
public:
	Room(std::string fname);
	~Room(void);
	void update(bool intro);
	void render(sf::RenderWindow* w);
	void renderCodeBox(sf::RenderWindow* w);
	std::vector<Tile> tiles;

	void generateCode();

	bool getComplete();
	CodeBox* getCodeBox();
	CheckBox* getPopUp();

	void initialiseSounds();
	void setComplete();

	bool getKillPlayer();


	void setTutorial(bool tut);
	bool isTutorial() {return tutorial;}

	void firstTutorialSection();
	void secondTutorialSection();

	int getTutorialSection() {return tutorialSection;}

	BadGuy * getBadGuy();

	sf::Vector2f* getPDALightPos() { return PDALightPos; }
	void setPDALightPos(sf::Vector2f* inPos);

private:
	// Declare and load a texture
	sf::Texture texture;
	sf::Sprite background;

	bool complete;
	
	Door* t_door;
	Door* b_door;

	std::vector<CodeElement> elements;
	CodeBox* codeBox;
	CheckBox* pop_up;

	UIWidget* pdaExplanation;
	UIWidget* codeExplanation;
	
	BadGuy wraith;

	std::vector<sf::Sound> soundList; 
	sf::SoundBuffer breathingBuffer;
	sf::SoundBuffer pipeBuffer;
	sf::SoundBuffer emergencyBuffer;
	sf::SoundBuffer terminatedBuffer;
	sf::SoundBuffer decliningBuffer;
	sf::SoundBuffer seriousBuffer;

	bool soundPlaying;

	bool tutorial;

	int tutorialSection;

	sf::Vector2f* PDALightPos;
 
	
	//PDA door_code;
};//Room

#endif