#ifndef PEEDEEAY_H
#define PEEDEEAY_H

#include<SFML\Window.hpp>
#include<SFML\Graphics.hpp>
#include "Pickup.h"

class peedeeay : public Pickup
{
public:
	peedeeay(int *code);
	~peedeeay();

	int* getCode();
	void render();

private:
	int *code;


};

#endif // PICKUP.H