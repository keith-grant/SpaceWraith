#include "Pickup.h"

Pickup::Pickup()
{
	tex.loadFromFile("art/tile_oscil.png");
	sprite.setTexture(tex);
	sprite.setColor(sf::Color(255, 255, 255, 255));
	sprite.setPosition(sf::Vector2f(0,0));
}

Pickup::~Pickup()
{

}