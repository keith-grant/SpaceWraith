#pragma once
#ifndef BAD_GUY_H
#define BAD_GUY_H

#include<SFML\Window.hpp>
#include<SFML\Graphics.hpp>
#include<SFML\Audio.hpp>
#include <iostream>
#include <random>
#include <time.h>


class BadGuy
{
public:
	BadGuy(void);
	~BadGuy(void);
	void update();
	void render(sf::RenderWindow *w);
	bool killPlayer;
	void pauseSound();
	void playSound();
	void setIncreaseRates(int levelNo);
	void setPosition(sf::Vector2f pos);
	float getCurrentPitch() {return pitch;}
	float getDeathCutOff() {return deathCutoff;}
private:
	sf::Texture tex;
	sf::Sprite sprite;

	sf::SoundBuffer buffer;
	sf::Sound beat;
	float deathCutoff;
	
	float volume, pitch;
	int level_number;

	


	
	
	
};

#endif